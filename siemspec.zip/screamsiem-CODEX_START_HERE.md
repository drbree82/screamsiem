# Codex Start Here

Read these files in order:

1. `SPEC.md`
2. `ARCHITECTURE.md`
3. `.ai/tickets/000-execution-rules.md`
4. Ticket files in numeric order

## Mission

Build the smallest functioning ScreamSIEM MVP that proves this loop:

```text
SSH host
-> baseline
-> live logs/process/socket state
-> deterministic finding
-> GPT-5.6 investigation through local read-only MCP tools
-> screaming dashboard
-> approval-gated typed fix OR manual one-line command
```

## Do not wander

Do not add:

- React;
- Kubernetes;
- Docker as a requirement;
- eBPF;
- Windows;
- multi-tenancy;
- arbitrary shell tools;
- production SOC features;
- generic architecture layers with no acceptance-test value.

## Priority

1. Make the deterministic demo work.
2. Make real SSH work.
3. Make GPT-5.6 tool investigation work.
4. Make one gated mutation work.
5. Polish only after tests pass.

Run tests after each ticket. Commit-sized changes are preferred.
