# ScreamSIEM Architecture

This document is the compact architectural map for Codex. `SPEC.md` is authoritative when details conflict.

## System diagram

```mermaid
flowchart LR
    Admin["Sysadmin<br/>Browser + CLI"]
    Proxy["Optional reverse proxy<br/>auth/TLS owned by operator"]
    Web["ScreamSIEM central server<br/>FastAPI :8080<br/>Dashboard + API + SSE"]
    DB[("SQLite<br/>hosts, baselines, events,<br/>findings, actions, timeline")]
    Detect["Baseline + deterministic<br/>detector engine"]
    GPT["GPT-5.6<br/>Responses API"]
    Adapter["Local MCP-to-Responses adapter<br/>read tools only during investigation"]
    Approval["Approval service<br/>exact-action token signer"]
    Supervisor["Host bridge supervisor<br/>port allocator 9100-9199"]

    subgraph Loopback["SIEM box — loopback-only control plane"]
        Web
        DB
        Detect
        Adapter
        Approval
        Supervisor

        subgraph B1["Host bridge: web-01"]
            MCP1["MCP :9100<br/>typed tools"]
            SSH1["SSH transport<br/>persistent connection"]
            C1["Collectors<br/>journalctl -f<br/>tail -F<br/>ps / ss / systemd / metrics"]
        end

        subgraph B2["Host bridge: db-01"]
            MCP2["MCP :9101<br/>typed tools"]
            SSH2["SSH transport"]
            C2["Collectors"]
        end
    end

    H1["Linux host web-01"]
    H2["Linux host db-01"]

    Admin -->|localhost or proxy| Web
    Admin -->|CLI add host| Web
    Proxy --> Web
    Web <--> DB
    Web --> Detect
    Detect -->|worthy finding| Web
    Web -->|bounded evidence + function schemas| GPT
    GPT -->|read tool call| Adapter
    Adapter -->|MCP call| MCP1
    Adapter -->|MCP call| MCP2
    MCP1 --> Adapter
    MCP2 --> Adapter
    GPT -->|structured assessment + recommendations| Web

    Web --> Supervisor
    Supervisor --> MCP1
    Supervisor --> MCP2
    C1 -->|internal event/metric ingestion| Web
    C2 -->|internal event/metric ingestion| Web

    MCP1 <--> SSH1
    SSH1 <--> H1
    C1 --> SSH1

    MCP2 <--> SSH2
    SSH2 <--> H2
    C2 --> SSH2

    Web -->|pending action| Approval
    Admin -->|approve exact action| Approval
    Approval -->|signed short-lived token| Web
    Web -->|mutable MCP call + token| MCP1
    MCP1 -->|typed SSH command| SSH1
    SSH1 --> H1
    MCP1 -->|result| Web
```

## Event and investigation sequence

```mermaid
sequenceDiagram
    participant Host as Linux host
    participant Bridge as Local host MCP bridge
    participant Central as ScreamSIEM central
    participant Detector as Detector engine
    participant GPT as GPT-5.6
    participant Admin as Sysadmin

    Bridge->>Host: SSH stream journalctl -f / tail -F
    Bridge->>Host: Poll ps, ss, systemd, /proc
    Host-->>Bridge: Log lines and state
    Bridge->>Central: Normalised event + metric
    Central->>Detector: Evaluate event against baseline
    Detector-->>Central: Create/update finding
    Central-->>Admin: SSE critical alert
    Central->>GPT: Bounded evidence + read-tool schemas
    GPT->>Central: Call inspect_process(pid)
    Central->>Bridge: MCP inspect_process(pid)
    Bridge->>Host: Read-only SSH inspection
    Host-->>Bridge: Bounded result
    Bridge-->>Central: MCP result
    Central-->>GPT: Tool output
    GPT-->>Central: Structured assessment and actions
    Central-->>Admin: Explanation, evidence, confidence, actions
```

## Approval sequence

```mermaid
sequenceDiagram
    participant GPT as GPT-5.6
    participant Central as Central SIEM
    participant Admin as Sysadmin
    participant Bridge as Host MCP bridge
    participant Host as Linux host

    GPT-->>Central: Recommend stop_process(pid, expected_start_time)
    Central->>Central: Store immutable pending action
    Central-->>Admin: Show exact target, arguments, impact, risk
    Admin->>Central: Approve
    Central->>Central: Sign exact action + expiry + nonce
    Central->>Bridge: MCP stop_process(..., approval_token)
    Bridge->>Bridge: Verify signature, host, tool, args, expiry, nonce
    Bridge->>Host: Typed command (no arbitrary shell)
    Host-->>Bridge: Result
    Bridge-->>Central: Execution result
    Central->>Central: Mark token used; append timeline
    Central-->>Admin: Show success/failure
```

## Manual fallback sequence

```mermaid
sequenceDiagram
    participant GPT as GPT-5.6
    participant Central as Central SIEM
    participant Admin as Sysadmin
    participant Host as Linux host

    GPT-->>Central: Manual action + one-line command + impact + verification
    Central-->>Admin: Label as model-generated; show copy button only
    Admin->>Admin: Review and decide
    opt Sysadmin chooses to run it
        Admin->>Host: Paste command in own terminal
        Admin->>Central: Optionally mark action performed
    end
```

## Component rules

| Component | May read host | May mutate host | Holds SSH key | Holds approval secret | Visible to GPT |
|---|---:|---:|---:|---:|---:|
| Central server | Through MCP | Through approved MCP call | No | Yes | N/A |
| Host bridge | Yes | Typed tools with valid token | Yes, one host only | No | Tool schema/results |
| GPT-5.6 | Through read-tool adapter | No direct mutation | No | No | Evidence and read tools |
| Browser/sysadmin | Through UI | Approves exact actions | No | No | N/A |
| Managed host | Local data | Local execution target | No | No | Untrusted evidence only |

## Golden path

```text
host add
  -> allocate 127.0.0.1:9100
  -> start bridge
  -> SSH profile
  -> save baseline
  -> stream logs + poll state
  -> normalise event
  -> deterministic detector
  -> finding
  -> GPT-5.6 read-tool investigation
  -> dashboard screams
  -> approve typed action OR copy manual one-liner
  -> timeline
```
